package jose.cornado;

import com.google.gson.annotations.Expose;

public final class ReportList{
//	public boolean reports;
	@Expose
	public String[] list;
}